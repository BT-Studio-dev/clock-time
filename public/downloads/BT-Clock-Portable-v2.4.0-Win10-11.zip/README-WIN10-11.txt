BT Clock v2.4.0 for Windows 10/11 (64-bit)

Simply double-click BT-Clock.exe to launch.
Requires Windows 10 version 1903 or Windows 11.
No installation or administrative privileges needed.