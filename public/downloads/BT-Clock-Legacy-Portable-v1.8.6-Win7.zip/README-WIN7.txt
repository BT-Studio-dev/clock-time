BT Clock Legacy v1.8.6 for Windows 7 SP1+ / Windows 8.1

Standalone compatibility build with embedded legacy rendering engine.
Supports Windows 7 SP1 (KB4474419 patch recommended).